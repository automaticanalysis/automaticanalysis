% Automatic analysis
% User master script example (aa version 5.*.*) - c.a. 2.5h
%
% Tibor Auer, MRC-CBSU
% 01-02-2016
